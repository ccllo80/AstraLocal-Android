# بناء ملف APK — Astra Local 0.5.0

## عبر GitHub Actions

1. ارفع محتويات مجلد `AstraLocal` إلى مستودع GitHub تملكه، على الفرع `main`.
2. افتح تبويب **Actions** في المستودع.
3. اختر سير العمل **Build Astra Local APK**.
4. اضغط **Run workflow** ثم **Run workflow** مرة أخرى.
5. انتظر حتى تصبح النتيجة خضراء، ثم افتح تشغيل البناء.
6. من قسم **Artifacts** نزّل `Astra-Local-debug`، وافتح ملف ZIP الناتج لتحصل على `app-debug.apk`.

## عبر Android Studio

- افتح مجلد المشروع في إصدار حديث من Android Studio.
- استخدم JDK 17 وثبّت Android SDK Platform 36 وBuild Tools 36.0.0.
- نفّذ مزامنة Gradle، ثم اختر `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
- ملف APK التجريبي يظهر عادةً في `app/build/outputs/apk/debug/app-debug.apk`.

## ملاحظة مهمة

ملف APK التجريبي (debug) مناسب للتثبيت والاختبار، لكنه ليس إصداراً نهائياً موقعاً بمفتاح نشر. يجب اختبار تحميل النموذج، التوليد، الذاكرة، الحرارة، وتبديل المحادثات على الهاتف قبل اعتبار التطبيق مستقراً.

package com.astralocal.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.coroutines.launch

private val Ink = Color(0xFF090A0D)
private val Panel = Color(0xFF14171D)
private val Panel2 = Color(0xFF1C2028)
private val Silver = Color(0xFFC7CDD6)
private val Muted = Color(0xFF8993A2)
private val Accent = Color(0xFFB7A47A)

class MainActivity : ComponentActivity() {
    private val chatViewModel: ChatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val colors = darkColorScheme(
                primary = Accent,
                onPrimary = Ink,
                background = Ink,
                onBackground = Silver,
                surface = Panel,
                onSurface = Silver,
                secondary = Muted
            )
            MaterialTheme(colorScheme = colors) {
                AstraScreen(chatViewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AstraScreen(vm: ChatViewModel) {
    val messages by vm.messages.collectAsState()
    val conversations by vm.conversations.collectAsState()
    val memories by vm.memories.collectAsState()
    val status by vm.status.collectAsState()
    val modelReady by vm.modelReady.collectAsState()
    val busy by vm.busy.collectAsState()
    val progress by vm.downloadProgress.collectAsState()
    val settings by vm.settings.collectAsState()
    var input by remember { mutableStateOf("") }
    var showMemory by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    val importModel = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) vm.importModel(uri)
    }

    LaunchedEffect(messages.lastOrNull()?.id, messages.lastOrNull()?.content?.length) {
        if (messages.isNotEmpty()) listState.scrollToItem(messages.lastIndex)
    }

    Scaffold(
        containerColor = Ink,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("ASTRA", color = Silver, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
                        Text("LOCAL INTELLIGENCE", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
                    }
                },
                actions = {
                    IconButton(onClick = { showSettings = true }, enabled = !busy) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Silver)
                    }
                    IconButton(onClick = { showHistory = true }) {
                        Icon(Icons.Default.History, contentDescription = "Conversation history", tint = Silver)
                    }
                    IconButton(onClick = { showMemory = true }) {
                        Icon(Icons.Default.Memory, contentDescription = "Memory", tint = Accent)
                    }
                    IconButton(onClick = { vm.newConversation() }) {
                        Icon(Icons.Default.Add, contentDescription = "New conversation", tint = Silver)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
            )
        },
        bottomBar = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Ink)
                    .navigationBarsPadding()
                    .imePadding()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(22.dp))
                        .background(Panel)
                        .padding(start = 14.dp, end = 7.dp, top = 7.dp, bottom = 7.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    TextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("احچي ويا أسترا...", color = Muted) },
                        enabled = modelReady && !busy,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            disabledContainerColor = Color.Transparent,
                            focusedTextColor = Silver,
                            unfocusedTextColor = Silver,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            cursorColor = Accent
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = {
                            val text = input.trim()
                            if (text.isNotEmpty()) {
                                input = ""
                                vm.send(text)
                            }
                        }),
                        maxLines = 5
                    )
                    IconButton(
                        onClick = {
                            val text = input.trim()
                            if (text.isNotEmpty()) {
                                input = ""
                                vm.send(text)
                            }
                        },
                        enabled = modelReady && !busy && input.isNotBlank(),
                        modifier = Modifier
                            .padding(bottom = 3.dp)
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(if (modelReady && !busy && input.isNotBlank()) Accent else Panel2)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = "Send", tint = if (modelReady && !busy && input.isNotBlank()) Ink else Muted)
                    }
                }
                Text(
                    "محلي على جهازك • لا تُرسل المحادثات إلى خادم",
                    color = Muted,
                    fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 7.dp)
                )
            }
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Ink)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(if (modelReady) Color(0xFF61B98A) else Accent))
                Spacer(Modifier.width(8.dp))
                Text(status, color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                if (!modelReady) {
                    TextButton(onClick = { vm.downloadModel() }, enabled = !busy) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("تنزيل النموذج")
                    }
                    TextButton(onClick = { importModel.launch(arrayOf("*/*")) }, enabled = !busy) {
                        Text("استيراد")
                    }
                }
            }

            if (progress in 1..99) {
                LinearProgressIndicator(
                    progress = { progress / 100f },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    color = Accent,
                    trackColor = Panel2
                )
                Text("تنزيل النموذج: $progress%", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(start = 16.dp, top = 4.dp))
            }

            if (messages.isEmpty()) {
                Spacer(Modifier.height(28.dp))
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier.size(76.dp).clip(RoundedCornerShape(24.dp)).background(Panel2),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("A", color = Accent, fontSize = 42.sp, fontWeight = FontWeight.Light)
                    }
                    Spacer(Modifier.height(20.dp))
                    Text("مساحة حديثك الخاصة", color = Silver, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (modelReady) "ابدأ بأي موضوع. أسترا يعمل محلياً على هاتفك." else "نزّل Qwen3-1.7B أولاً حتى تبدأ المحادثة.",
                        color = Muted,
                        fontSize = 13.sp
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(messages, key = { it.id }) { message ->
                        MessageBubble(message)
                    }
                }
            }
        }
    }

    if (showHistory) {
        AlertDialog(
            onDismissRequest = { showHistory = false },
            containerColor = Panel,
            title = { Text("محادثاتك", color = Silver) },
            text = {
                if (conversations.isEmpty()) {
                    Text("لا توجد محادثات محفوظة.", color = Muted)
                } else {
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 420.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(conversations, key = { it.id }) { conversation ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(
                                    onClick = {
                                        vm.openConversation(conversation.id)
                                        showHistory = false
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(conversation.title, color = Silver, maxLines = 2)
                                }
                                IconButton(onClick = { vm.deleteConversation(conversation.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete conversation", tint = Muted)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showHistory = false }) { Text("إغلاق", color = Accent) }
            },
            dismissButton = {
                TextButton(onClick = {
                    vm.newConversation()
                    showHistory = false
                }) { Text("محادثة جديدة", color = Silver) }
            }
        )
    }

    if (showSettings) {
        SettingsDialog(
            settings = settings,
            onDismiss = { showSettings = false },
            onSave = { vm.updateSettings(it); showSettings = false }
        )
    }

    if (showMemory) {
        MemoryManagerDialog(
            memories = memories,
            onDismiss = { showMemory = false },
            onAdd = vm::addMemory,
            onUpdate = vm::updateMemory,
            onDelete = vm::deleteMemory
        )
    }
}


@Composable
private fun SettingsDialog(
    settings: AstraSettings,
    onDismiss: () -> Unit,
    onSave: (AstraSettings) -> Unit
) {
    var responseTokens by remember(settings) { mutableStateOf(settings.responseTokens.toFloat()) }
    var historyTurns by remember(settings) { mutableStateOf(settings.historyTurns.toFloat()) }
    var responseStyle by remember(settings) { mutableStateOf(settings.responseStyle) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("إعدادات أسترا", color = Silver, fontWeight = FontWeight.SemiBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("طول الرد", color = Silver, fontWeight = FontWeight.Medium)
                Text("${responseTokens.toInt()} رمز تقريباً كحد أقصى للتوليد", color = Muted, fontSize = 12.sp)
                Slider(
                    value = responseTokens,
                    onValueChange = { responseTokens = it },
                    valueRange = 128f..768f,
                    steps = 9,
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
                )
                HorizontalDivider(color = Panel2)
                Text("سياق المحادثة", color = Silver, fontWeight = FontWeight.Medium)
                Text("آخر ${historyTurns.toInt()} تبادلات من المستخدم والمساعد تُضاف للسياق", color = Muted, fontSize = 12.sp)
                Slider(
                    value = historyTurns,
                    onValueChange = { historyTurns = it },
                    valueRange = 2f..12f,
                    steps = 4,
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
                )
                HorizontalDivider(color = Panel2)
                Text("أسلوب الإجابة", color = Silver, fontWeight = FontWeight.Medium)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf("concise" to "مختصر", "balanced" to "متوازن", "detailed" to "مفصل").forEach { (key, label) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = responseStyle == key,
                                onClick = { responseStyle = key },
                                colors = RadioButtonDefaults.colors(selectedColor = Accent, unselectedColor = Muted)
                            )
                            Text(label, color = Silver, fontSize = 13.sp)
                        }
                    }
                }
                Text(
                    "ملاحظة: درجة الحرارة وTop-P وحجم نافذة النموذج غير متاحة عبر واجهة مكتبة التشغيل الحالية؛ لذلك لم نضع لها عناصر تحكم غير فعالة.",
                    color = Muted, fontSize = 11.sp, lineHeight = 16.sp
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(AstraSettings(responseTokens.toInt(), historyTurns.toInt(), responseStyle))
            }) { Text("حفظ الإعدادات", color = Accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = Muted) } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MemoryManagerDialog(
    memories: List<MemoryNote>,
    onDismiss: () -> Unit,
    onAdd: (String) -> Unit,
    onUpdate: (Long, String) -> Unit,
    onDelete: (Long) -> Unit
) {
    var editingId by remember { mutableStateOf<Long?>(null) }
    var draft by remember { mutableStateOf("") }
    var editorOpen by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("الذاكرة طويلة الأمد", color = Silver, fontWeight = FontWeight.SemiBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "هذه معلومات تختار حفظها بنفسك. تُخزّن على الهاتف وتُسترجع محلياً عند ارتباطها بسؤالك. لا تُحفظ المحادثات تلقائياً. لا تضف كلمات مرور أو بيانات شديدة الخصوصية.",
                    color = Muted,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("${memories.size} ذكريات محفوظة", color = Accent, fontSize = 11.sp, modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        editingId = null
                        draft = ""
                        editorOpen = true
                    }) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Accent, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("إضافة", color = Accent)
                    }
                }
                if (memories.isEmpty()) {
                    Text("لا توجد ذكريات بعد. يمكنك إضافة معلومة هنا، أو كتابة «تذكر أن...» أثناء المحادثة.", color = Muted, fontSize = 12.sp)
                } else {
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 340.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        items(memories, key = { it.id }) { memory ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel2).padding(start = 11.dp, end = 5.dp, top = 7.dp, bottom = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(memory.content, color = Silver, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.weight(1f))
                                IconButton(onClick = {
                                    editingId = memory.id
                                    draft = memory.content
                                    editorOpen = true
                                }) {
                                    Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = Muted, modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { onDelete(memory.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Muted, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق", color = Accent) } }
    )

    if (editorOpen) {
        AlertDialog(
            onDismissRequest = { editorOpen = false },
            containerColor = Panel,
            title = { Text(if (editingId == null) "إضافة ذكرى" else "تعديل الذكرى", color = Silver) },
            text = {
                OutlinedTextField(
                    value = draft,
                    onValueChange = { draft = it.take(1200) },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("اكتب المعلومة التي تريد أن يتذكرها أسترا") },
                    minLines = 3,
                    maxLines = 6,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Silver,
                        unfocusedTextColor = Silver,
                        focusedBorderColor = Accent,
                        unfocusedBorderColor = Muted,
                        cursorColor = Accent
                    )
                )
            },
            confirmButton = {
                TextButton(
                    enabled = draft.isNotBlank(),
                    onClick = {
                        val id = editingId
                        if (id == null) onAdd(draft) else onUpdate(id, draft)
                        editorOpen = false
                    }
                ) { Text("حفظ", color = Accent) }
            },
            dismissButton = { TextButton(onClick = { editorOpen = false }) { Text("إلغاء", color = Muted) } }
        )
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val isUser = message.role == "user"
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            Modifier
                .widthIn(max = 320.dp)
                .clip(RoundedCornerShape(
                    topStart = 18.dp, topEnd = 18.dp,
                    bottomStart = if (isUser) 18.dp else 5.dp,
                    bottomEnd = if (isUser) 5.dp else 18.dp
                ))
                .background(if (isUser) Panel2 else Panel)
                .padding(horizontal = 15.dp, vertical = 12.dp)
        ) {
            Text(
                if (isUser) "أنت" else "ASTRA",
                color = if (isUser) Muted else Accent,
                fontSize = 9.sp,
                letterSpacing = 1.5.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(5.dp))
            Text(message.content, color = Silver, fontSize = 14.sp, lineHeight = 21.sp)
        }
    }
}

data class ChatMessage(
    val id: Long,
    val role: String,
    val content: String,
    val createdAt: Long
)

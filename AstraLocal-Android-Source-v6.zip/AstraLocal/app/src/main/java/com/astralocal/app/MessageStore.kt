package com.astralocal.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.Locale
import java.util.UUID

data class Conversation(val id: String, val title: String, val createdAt: Long, val updatedAt: Long)
data class MemoryNote(val id: Long, val content: String, val createdAt: Long, val updatedAt: Long)

class MessageStore(context: Context) : SQLiteOpenHelper(context, "astra_memory.db", null, 3) {
    init {
        setWriteAheadLoggingEnabled(true)
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
        db.execSQL("PRAGMA synchronous=NORMAL")
        db.execSQL("PRAGMA busy_timeout=5000")
    }
    override fun onCreate(db: SQLiteDatabase) = createSchema(db)

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("""CREATE TABLE IF NOT EXISTS conversations (
                id TEXT PRIMARY KEY NOT NULL, title TEXT NOT NULL,
                created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)""")
            db.execSQL("""CREATE TABLE IF NOT EXISTS messages_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT, conversation_id TEXT NOT NULL,
                role TEXT NOT NULL, content TEXT NOT NULL, created_at INTEGER NOT NULL,
                FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE)""")
            // Preserve the v1 single-thread history as one legacy conversation.
            db.execSQL("""
                INSERT OR IGNORE INTO conversations(id, title, created_at, updated_at)
                VALUES('legacy', 'المحادثة السابقة', 0, 0)
            """.trimIndent())
            db.execSQL("""
                INSERT INTO messages_new(id, conversation_id, role, content, created_at)
                SELECT id, 'legacy', role, content, created_at FROM messages
            """.trimIndent())
            db.execSQL("DROP TABLE IF EXISTS messages")
            db.execSQL("ALTER TABLE messages_new RENAME TO messages")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id, id)")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_messages_created ON messages(created_at DESC)")
        }
        if (oldVersion < 3) createMemorySchema(db)
    }

    private fun createMemorySchema(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            updated_at INTEGER NOT NULL)""")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_memories_updated ON memories(updated_at DESC)")
    }

    private fun createSchema(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE conversations (
            id TEXT PRIMARY KEY NOT NULL, title TEXT NOT NULL,
            created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)""")
        db.execSQL("""CREATE TABLE messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT, conversation_id TEXT NOT NULL,
            role TEXT NOT NULL, content TEXT NOT NULL, created_at INTEGER NOT NULL,
            FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE)""")
        db.execSQL("CREATE INDEX idx_messages_conversation ON messages(conversation_id, id)")
        db.execSQL("CREATE INDEX idx_messages_created ON messages(created_at DESC)")
        createMemorySchema(db)
    }

    @Synchronized fun addMemory(content: String): Long {
        val clean = content.trim().take(1200)
        require(clean.isNotBlank()) { "الذاكرة فارغة" }
        val now = System.currentTimeMillis()
        val values = ContentValues().apply {
            put("content", clean); put("created_at", now); put("updated_at", now)
        }
        return writableDatabase.insertOrThrow("memories", null, values)
    }

    @Synchronized fun updateMemory(id: Long, content: String) {
        val clean = content.trim().take(1200)
        require(clean.isNotBlank()) { "الذاكرة فارغة" }
        val values = ContentValues().apply {
            put("content", clean); put("updated_at", System.currentTimeMillis())
        }
        writableDatabase.update("memories", values, "id = ?", arrayOf(id.toString()))
    }

    @Synchronized fun deleteMemory(id: Long) {
        writableDatabase.delete("memories", "id = ?", arrayOf(id.toString()))
    }

    @Synchronized fun memories(): List<MemoryNote> {
        val result = mutableListOf<MemoryNote>()
        readableDatabase.rawQuery(
            "SELECT id, content, created_at, updated_at FROM memories ORDER BY updated_at DESC", null
        ).use { c ->
            while (c.moveToNext()) result += MemoryNote(c.getLong(0), c.getString(1), c.getLong(2), c.getLong(3))
        }
        return result
    }

    // Curated facts are ranked locally by token overlap; no embeddings or network calls.
    @Synchronized fun relevantMemories(query: String, limit: Int = 5): String {
        val terms = tokenize(query).filter { it.length >= 2 }.toSet()
        if (terms.isEmpty()) return ""
        return memories().mapNotNull { note ->
            val noteTerms = tokenize(note.content).toSet()
            val score = terms.count { it in noteTerms }
            if (score == 0) null else score to note.content
        }.sortedByDescending { it.first }.take(limit)
            .joinToString("\n") { "- ${it.second}" }.take(1800)
    }

    private fun tokenize(value: String): List<String> = value.lowercase(Locale.ROOT)
        .split(Regex("[^\\p{L}\\p{N}]+"))
        .filter { it.isNotBlank() }

    @Synchronized fun ensureConversation(): String =
        conversations().firstOrNull()?.id ?: createConversation()

    @Synchronized fun createConversation(title: String = "محادثة جديدة"): String {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val values = ContentValues().apply {
            put("id", id); put("title", title); put("created_at", now); put("updated_at", now)
        }
        writableDatabase.insertOrThrow("conversations", null, values)
        return id
    }

    @Synchronized fun conversations(): List<Conversation> {
        val result = mutableListOf<Conversation>()
        readableDatabase.rawQuery(
            "SELECT id, title, created_at, updated_at FROM conversations ORDER BY updated_at DESC", null
        ).use { c ->
            while (c.moveToNext()) result += Conversation(c.getString(0), c.getString(1), c.getLong(2), c.getLong(3))
        }
        return result
    }

    @Synchronized fun renameConversation(id: String, title: String) {
        val values = ContentValues().apply { put("title", title.take(48)) }
        writableDatabase.update("conversations", values, "id = ?", arrayOf(id))
    }

    @Synchronized private fun touchConversation(id: String) {
        val values = ContentValues().apply { put("updated_at", System.currentTimeMillis()) }
        writableDatabase.update("conversations", values, "id = ?", arrayOf(id))
    }

    @Synchronized fun deleteConversation(id: String) {
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("messages", "conversation_id = ?", arrayOf(id))
            writableDatabase.delete("conversations", "id = ?", arrayOf(id))
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }

    @Synchronized fun insert(conversationId: String, role: String, content: String): Long {
        val values = ContentValues().apply {
            put("conversation_id", conversationId); put("role", role)
            put("content", content); put("created_at", System.currentTimeMillis())
        }
        val id = writableDatabase.insert("messages", null, values)
        touchConversation(conversationId)
        if (role == "user") {
            val count = readableDatabase.rawQuery(
                "SELECT COUNT(*) FROM messages WHERE conversation_id = ? AND role = 'user'",
                arrayOf(conversationId)
            ).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }
            if (count == 1) renameConversation(conversationId, content.take(42).ifBlank { "محادثة جديدة" })
        }
        return id
    }

    @Synchronized fun update(id: Long, content: String) {
        val values = ContentValues().apply { put("content", content) }
        writableDatabase.update("messages", values, "id = ?", arrayOf(id.toString()))
    }

    @Synchronized fun recent(conversationId: String, limit: Int): List<ChatMessage> {
        val result = mutableListOf<ChatMessage>()
        readableDatabase.rawQuery(
            "SELECT id, role, content, created_at FROM messages WHERE conversation_id = ? ORDER BY id DESC LIMIT ?",
            arrayOf(conversationId, limit.toString())
        ).use { c ->
            while (c.moveToNext()) result += ChatMessage(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3))
        }
        return result.asReversed()
    }

}
